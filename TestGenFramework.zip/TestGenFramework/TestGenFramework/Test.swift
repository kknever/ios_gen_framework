//
//  Test.swift
//  TestGenFramework
//
//  Created by KeepGo on 2023/5/26.
//

import Foundation

public func testStr() -> String {
    print("call testStr()")
    return "调用了framwork中的swift方法~!"
}
