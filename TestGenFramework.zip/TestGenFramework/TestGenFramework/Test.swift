//
//  Test.swift
//  TestGenFramework
//
//  Created by KeepGo on 2023/5/26.
//

import Foundation

public func testStr() -> String {
    print("call testStr()")
    
    let result = cadd(100, 200)
    print("framework中的swift方法调用了C++方法: \(result)")
    
    return "调用了framwork中的swift方法~!"
}
