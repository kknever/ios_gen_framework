//
//  test.cpp
//  TestGenFramework
//
//  Created by KeepGo on 2023/5/26.
//

#include "test.h"
#include <openssl/crypto.h>

int cadd(int a, int b) {
    printf("调用了c++方法\n");
    
    printf("C++方法中调用了openssl静态库 ver: %s\n", OpenSSL_version(OPENSSL_VERSION));
    
    return a + b;
}
