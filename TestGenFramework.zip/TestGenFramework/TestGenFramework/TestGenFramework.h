//
//  TestGenFramework.h
//  TestGenFramework
//
//  Created by KeepGo on 2023/5/26.
//

#import <Foundation/Foundation.h>

//! Project version number for TestGenFramework.
FOUNDATION_EXPORT double TestGenFrameworkVersionNumber;

//! Project version string for TestGenFramework.
FOUNDATION_EXPORT const unsigned char TestGenFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestGenFramework/PublicHeader.h>


