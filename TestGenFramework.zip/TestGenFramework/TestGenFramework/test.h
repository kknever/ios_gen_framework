//
//  test.hpp
//  TestGenFramework
//
//  Created by KeepGo on 2023/5/26.
//

#ifndef test_h
#define test_h

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

int cadd(int a, int b);
    
#ifdef __cplusplus
}
#endif

#endif /* test_hpp */
